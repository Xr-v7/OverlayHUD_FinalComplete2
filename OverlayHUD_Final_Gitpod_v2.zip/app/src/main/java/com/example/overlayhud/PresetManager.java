package com.example.overlayhud;
import android.content.*;
public class PresetManager {
    private static final String KEY="preset_json_v2";
    public static void save(Context ctx, Preset p){
        try{
            ctx.getSharedPreferences("overlay_prefs", Context.MODE_PRIVATE)
                .edit().putString(KEY, p.toJson().toString()).apply();
        }catch(Exception ignore){}
    }
    public static Preset load(Context ctx){
        String s=ctx.getSharedPreferences("overlay_prefs", Context.MODE_PRIVATE)
                .getString(KEY, "");
        if(s==null||s.isEmpty()) return new Preset();
        return Preset.fromJson(s);
    }
}

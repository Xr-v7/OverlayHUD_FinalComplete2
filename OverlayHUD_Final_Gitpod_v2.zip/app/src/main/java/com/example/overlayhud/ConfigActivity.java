package com.example.overlayhud;
import android.app.Activity;
import android.os.Bundle;
import android.view.*;
import android.widget.*;
import androidx.annotation.Nullable;
import java.util.*;
public class ConfigActivity extends Activity implements FloatingButtonView.Listener {
    private FrameLayout canvas;
    private Preset preset;
    private FloatingEditor editor;
    @Override protected void onCreate(@Nullable Bundle b){
        super.onCreate(b);
        setContentView(R.layout.activity_config);
        canvas=findViewById(R.id.canvasRoot);
        preset=PresetManager.load(this);
        findViewById(R.id.btnExit).setOnClickListener(v->finish());
        findViewById(R.id.btnSave).setOnClickListener(v->savePreset());
        findViewById(R.id.btnClear).setOnClickListener(v->clearAll());
        findViewById(R.id.btnAddButton).setOnClickListener(v->addButton());
        findViewById(R.id.btnAddPanel).setOnClickListener(v->addPanel());
        renderFromPreset();
    }
    private void renderFromPreset(){
        canvas.removeAllViews();
        // tool bar already in layout (first child), so add after it; keep layer: panels bottom, buttons top
        for(Preset.ButtonCfg c: preset.items){
            if("panel".equals(c.type)){
                MousePanelView v=new MousePanelView(this);
                v.cfg=c; v.editing=true; v.applyCfg();
                v.setX(c.x); v.setY(c.y);
                canvas.addView(v);
            }
        }
        for(Preset.ButtonCfg c: preset.items){
            if(!"panel".equals(c.type)){
                FloatingButtonView v=new FloatingButtonView(this);
                v.cfg=c; v.editing=true; v.listener=this; v.applyCfg();
                v.setX(c.x); v.setY(c.y); v.setElevation(20f);
                canvas.addView(v);
            }
        }
    }
    private void addButton(){
        Preset.ButtonCfg c=new Preset.ButtonCfg();
        c.id=UUID.randomUUID().toString(); c.type="button"; c.size=120; c.alpha=0.6f;
        c.keyCode=android.view.KeyEvent.KEYCODE_W; c.toggle=false; c.passThroughWhileHeld=false;
        c.x=200; c.y=400;
        preset.items.add(c); renderFromPreset();
    }
    private void addPanel(){
        // Only one panel is recommended; but we let multiple if desired
        Preset.ButtonCfg c=new Preset.ButtonCfg();
        c.id=UUID.randomUUID().toString(); c.type="panel"; c.size=220; c.alpha=0.0f;
        c.x=600; c.y=600;
        preset.items.add(c); renderFromPreset();
    }
    private void savePreset(){
        // persist current positions from views
        for(int i=0;i<canvas.getChildCount();i++){
            View v=canvas.getChildAt(i);
            if(v instanceof FloatingButtonView){
                FloatingButtonView fb=(FloatingButtonView)v;
                fb.cfg.x=fb.getX(); fb.cfg.y=fb.getY(); fb.cfg.size=fb.getWidth(); fb.cfg.alpha=fb.getAlpha();
            } else if(v instanceof MousePanelView){
                MousePanelView mp=(MousePanelView)v;
                mp.cfg.x=mp.getX(); mp.cfg.y=mp.getY(); mp.cfg.size=mp.getWidth(); mp.cfg.alpha=0f;
            }
        }
        PresetManager.save(this, preset);
        Toast.makeText(this, "Preset guardado", Toast.LENGTH_SHORT).show();
    }
    private void clearAll(){
        preset.items.clear(); renderFromPreset();
    }
    @Override public void onRequestEdit(FloatingButtonView v){
        if(editor!=null && editor.isShowing()) editor.dismiss();
        editor=new FloatingEditor(this, v.cfg);
        editor.show();
        // position near the view
        Window w=editor.getWindow();
        if(w!=null){
            WindowManager.LayoutParams p=w.getAttributes();
            p.x=(int)(v.getX()); p.y=(int)(v.getY()); w.setAttributes(p);
        }
    }
}

package com.example.overlayhud;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Color;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
public class FloatingButtonView extends View {
    public interface Listener { void onRequestEdit(FloatingButtonView v); }
    private Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
    public Preset.ButtonCfg cfg;
    public boolean editing=false;
    public Listener listener;
    private boolean active=false;
    public FloatingButtonView(Context c){ super(c); init();}
    public FloatingButtonView(Context c, AttributeSet a){ super(c,a); init();}
    private void init(){ setWillNotDraw(false); paint.setColor(Color.BLACK); setAlpha(0.6f); }
    @Override protected void onDraw(Canvas canvas){
        float r=Math.min(getWidth(),getHeight())/2f;
        paint.setColor(Color.BLACK);
        canvas.drawCircle(getWidth()/2f, getHeight()/2f, r, paint);
        if(editing){
            Paint p2=new Paint(Paint.ANTI_ALIAS_FLAG); p2.setStyle(Paint.Style.STROKE); p2.setColor(Color.WHITE); p2.setStrokeWidth(3);
            canvas.drawCircle(getWidth()/2f, getHeight()/2f, r-3, p2);
        }
    }
    @Override public boolean onTouchEvent(MotionEvent e){
        if(editing){
            // drag move
            if(e.getAction()==MotionEvent.ACTION_MOVE){
                setX(getX()+e.getX()-getWidth()/2f);
                setY(getY()+e.getY()-getHeight()/2f);
            } else if(e.getAction()==MotionEvent.ACTION_UP){
                performClick();
            }
            return true;
        } else {
            switch(e.getActionMasked()){
                case MotionEvent.ACTION_DOWN:
                    if(cfg.toggle){
                        active=!active;
                        InputBridge.sendKey(getContext(), cfg.keyCode, active);
                    } else {
                        active=true; InputBridge.sendKey(getContext(), cfg.keyCode, true);
                    }
                    // request editor on long press in runtime? disabled
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if(active && !cfg.toggle && cfg.passThroughWhileHeld){
                        // simulate camera move under finger
                        InputBridge.sendMove(getContext(), e.getRawX(), e.getRawY());
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    if(!cfg.toggle && active){
                        InputBridge.sendKey(getContext(), cfg.keyCode, false);
                        active=false;
                    }
                    return true;
            }
            return true;
        }
    }
    @Override public boolean performClick(){
        super.performClick();
        if(editing && listener!=null) listener.onRequestEdit(this);
        return true;
    }
    public void applyCfg(){
        int s=(int)cfg.size; setLayoutParams(new android.widget.FrameLayout.LayoutParams(s,s));
        setAlpha(cfg.alpha);
    }
}

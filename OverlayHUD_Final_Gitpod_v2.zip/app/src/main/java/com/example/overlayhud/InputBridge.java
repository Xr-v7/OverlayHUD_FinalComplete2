package com.example.overlayhud;
import android.content.*;
public class InputBridge {
    public static final String ACTION_KEY="com.example.overlayhud.KEY";
    public static final String ACTION_GESTURE="com.example.overlayhud.GESTURE";
    public static final String EXTRA_CODE="code";
    public static final String EXTRA_DOWN="down";
    public static final String EXTRA_X="x";
    public static final String EXTRA_Y="y";
    public static void sendKey(Context ctx, int code, boolean down){
        Intent i=new Intent(ACTION_KEY); i.putExtra(EXTRA_CODE,code); i.putExtra(EXTRA_DOWN,down);
        ctx.sendBroadcast(i);
    }
    public static void sendMove(Context ctx, float x, float y){
        Intent i=new Intent(ACTION_GESTURE); i.putExtra(EXTRA_X,x); i.putExtra(EXTRA_Y,y);
        ctx.sendBroadcast(i);
    }
}

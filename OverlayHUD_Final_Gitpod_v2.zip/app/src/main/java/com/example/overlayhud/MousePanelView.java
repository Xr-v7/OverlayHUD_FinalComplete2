package com.example.overlayhud;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
public class MousePanelView extends View {
    public Preset.ButtonCfg cfg;
    public boolean editing=false;
    private Paint frame=new Paint(Paint.ANTI_ALIAS_FLAG);
    public MousePanelView(Context c){ super(c); init();}
    public MousePanelView(Context c, AttributeSet a){ super(c,a); init();}
    private void init(){ frame.setColor(Color.WHITE); frame.setStyle(Paint.Style.STROKE); frame.setStrokeWidth(3); setAlpha(0.2f); }
    @Override protected void onDraw(Canvas canvas){
        if(editing){
            canvas.drawRect(0,0,getWidth(),getHeight(), frame);
        } // en uso real es invisible (alpha 0) y no tocable desde el servicio
    }
    @Override public boolean onTouchEvent(MotionEvent e){
        if(editing){
            if(e.getAction()==MotionEvent.ACTION_MOVE){
                setX(getX()+e.getX()-getWidth()/2f);
                setY(getY()+e.getY()-getHeight()/2f);
            }
            return true;
        }
        return false;
    }
    public void applyCfg(){
        int s=(int)cfg.size; setLayoutParams(new android.widget.FrameLayout.LayoutParams(s,s));
        setAlpha(editing?0.2f:0f);
    }
}

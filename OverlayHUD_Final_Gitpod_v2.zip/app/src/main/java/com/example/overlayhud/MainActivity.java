package com.example.overlayhud;
import android.Manifest;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
public class MainActivity extends AppCompatActivity {
    @Override protected void onCreate(@Nullable Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button btnStart=findViewById(R.id.btnStart);
        Button btnConfig=findViewById(R.id.btnConfig);
        btnStart.setOnClickListener(v->{
            ensurePerms();
            startService(new Intent(this, OverlayHudService.class));
        });
        btnConfig.setOnClickListener(v-> startActivity(new Intent(this, ConfigActivity.class)));
    }
    private void ensurePerms(){
        if(!Settings.canDrawOverlays(this)){
            Intent i=new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName()));
            startActivity(i);
        }
        if(Build.VERSION.SDK_INT>=33){
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 100);
        }
        // Accesibilidad e IME deben habilitarse manualmente por el usuario
    }
}

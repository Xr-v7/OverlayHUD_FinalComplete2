package com.example.overlayhud;
import org.json.*;
import java.util.*;
public class Preset {
    public static class ButtonCfg {
        public String id;
        public String type; // "button" or "panel"
        public float x, y, size, alpha;
        public int keyCode; // ignored for panel
        public boolean toggle;
        public boolean passThroughWhileHeld; // allow camera drag gestures while holding
        public ButtonCfg(){}
        public JSONObject toJson() throws JSONException{
            JSONObject o=new JSONObject();
            o.put("id",id); o.put("type",type); o.put("x",x); o.put("y",y);
            o.put("size",size); o.put("alpha",alpha);
            o.put("keyCode",keyCode); o.put("toggle",toggle);
            o.put("passThroughWhileHeld", passThroughWhileHeld);
            return o;
        }
        public static ButtonCfg fromJson(JSONObject o) throws JSONException{
            ButtonCfg c=new ButtonCfg();
            c.id=o.optString("id",UUID.randomUUID().toString());
            c.type=o.optString("type","button"); c.x=(float)o.optDouble("x",100);
            c.y=(float)o.optDouble("y",100); c.size=(float)o.optDouble("size",120);
            c.alpha=(float)o.optDouble("alpha",0.6); c.keyCode=o.optInt("keyCode",29);
            c.toggle=o.optBoolean("toggle",false);
            c.passThroughWhileHeld=o.optBoolean("passThroughWhileHeld",false);
            return c;
        }
    }
    public String name="Default";
    public List<ButtonCfg> items = new ArrayList<>();
    public JSONObject toJson() throws JSONException{
        JSONObject o=new JSONObject(); o.put("name",name);
        JSONArray arr=new JSONArray(); for(ButtonCfg c:items) arr.put(c.toJson());
        o.put("items",arr); return o;
    }
    public static Preset fromJson(String s){
        try{
            JSONObject o=new JSONObject(s); Preset p=new Preset();
            p.name=o.optString("name","Default"); JSONArray arr=o.optJSONArray("items");
            if(arr!=null){ for(int i=0;i<arr.length();i++){ p.items.add(ButtonCfg.fromJson(arr.getJSONObject(i))); } }
            return p;
        }catch(Exception e){ return new Preset(); }
    }
}

package com.example.overlayhud;
import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.view.accessibility.AccessibilityEvent;
import android.content.*;
public class MouseAccessibilityService extends AccessibilityService {
    BroadcastReceiver receiver=new BroadcastReceiver(){
        @Override public void onReceive(Context c, Intent i){
            if(InputBridge.ACTION_GESTURE.equals(i.getAction())){
                float x=i.getFloatExtra(InputBridge.EXTRA_X, 0);
                float y=i.getFloatExtra(InputBridge.EXTRA_Y, 0);
                Path p=new Path(); p.moveTo(x,y); p.lineTo(x+1,y+1);
                GestureDescription.StrokeDescription stroke=new GestureDescription.StrokeDescription(p, 0, 8);
                GestureDescription g=new GestureDescription.Builder().addStroke(stroke).build();
                dispatchGesture(g, null, null);
            }
        }
    };
    @Override public void onServiceConnected(){
        super.onServiceConnected();
        registerReceiver(receiver, new IntentFilter(InputBridge.ACTION_GESTURE));
    }
    @Override public void onDestroy(){
        super.onDestroy();
        unregisterReceiver(receiver);
    }
    @Override public void onAccessibilityEvent(AccessibilityEvent event) {}
    @Override public void onInterrupt() {}
}

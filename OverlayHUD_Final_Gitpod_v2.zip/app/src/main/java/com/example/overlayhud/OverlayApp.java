package com.example.overlayhud;
import android.app.Application;
public class OverlayApp extends Application {
    @Override public void onCreate(){ super.onCreate(); }
}

package com.example.overlayhud;
import android.inputmethodservice.InputMethodService;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.InputConnection;
import android.content.*;
public class WASDInputMethodService extends InputMethodService {
    private BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if(InputBridge.ACTION_KEY.equals(intent.getAction())){
                int code=intent.getIntExtra(InputBridge.EXTRA_CODE, KeyEvent.KEYCODE_A);
                boolean down=intent.getBooleanExtra(InputBridge.EXTRA_DOWN,false);
                InputConnection ic=getCurrentInputConnection();
                if(ic!=null){
                    long now=System.currentTimeMillis();
                    int action= down? KeyEvent.ACTION_DOWN : KeyEvent.ACTION_UP;
                    KeyEvent ev=new KeyEvent(now, now, action, code, 0);
                    ic.sendKeyEvent(ev);
                }
            }
        }
    };
    @Override public void onCreate(){
        super.onCreate();
        registerReceiver(receiver, new android.content.IntentFilter(InputBridge.ACTION_KEY));
    }
    @Override public void onDestroy(){
        super.onDestroy();
        unregisterReceiver(receiver);
    }
    @Override public View onCreateInputView(){ return null; } // no UI
}

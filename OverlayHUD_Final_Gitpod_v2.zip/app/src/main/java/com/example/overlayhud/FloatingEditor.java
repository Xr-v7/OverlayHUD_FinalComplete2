package com.example.overlayhud;
import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.*;
import android.widget.*;
public class FloatingEditor extends Dialog {
    private Preset.ButtonCfg cfg;
    public FloatingEditor(Context c, Preset.ButtonCfg cfg){ super(c, android.R.style.Theme_Translucent_NoTitleBar); this.cfg=cfg; }
    @Override protected void onCreate(Bundle savedInstance){
        super.onCreate(savedInstance);
        Window w=getWindow();
        if(w!=null){
            w.setLayout(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT);
            w.setGravity(Gravity.TOP|Gravity.START);
        }
        setContentView(R.layout.floating_editor);
        TextView title=findViewById(R.id.tvTitle);
        if("panel".equals(cfg.type)) title.setText("Editar panel mouse");
        CheckBox chkToggle=findViewById(R.id.chkToggle);
        CheckBox chkPass=findViewById(R.id.chkPassThrough);
        Spinner spKey=findViewById(R.id.spKey);
        SeekBar seekSize=findViewById(R.id.seekSize);
        SeekBar seekAlpha=findViewById(R.id.seekAlpha);
        Button btnOk=findViewById(R.id.btnOk);
        Button btnCancel=findViewById(R.id.btnCancel);
        // populate keys
        String[] labels={"W","A","S","D","↑","↓","←","→","SPACE","ENTER","CLICK_IZQ","CLICK_DER"};
        int[] codes={android.view.KeyEvent.KEYCODE_W,android.view.KeyEvent.KEYCODE_A,android.view.KeyEvent.KEYCODE_S,android.view.KeyEvent.KEYCODE_D,
                     android.view.KeyEvent.KEYCODE_DPAD_UP,android.view.KeyEvent.KEYCODE_DPAD_DOWN,android.view.KeyEvent.KEYCODE_DPAD_LEFT,android.view.KeyEvent.KEYCODE_DPAD_RIGHT,
                     android.view.KeyEvent.KEYCODE_SPACE,android.view.KeyEvent.KEYCODE_ENTER, android.view.KeyEvent.KEYCODE_BUTTON_1, android.view.KeyEvent.KEYCODE_BUTTON_2};
        ArrayAdapter<String> ad=new ArrayAdapter<>(getContext(), android.R.layout.simple_spinner_dropdown_item, labels);
        spKey.setAdapter(ad);
        // init visibility
        if("panel".equals(cfg.type)){
            chkToggle.setVisibility(View.GONE);
            chkPass.setVisibility(View.GONE);
            spKey.setEnabled(false);
        } else {
            chkToggle.setChecked(cfg.toggle);
            chkPass.setChecked(cfg.passThroughWhileHeld);
            // pick initial index by key
            int idx=0;
            for(int i=0;i<codes.length;i++){ if(codes[i]==cfg.keyCode){ idx=i; break; } }
            spKey.setSelection(idx);
        }
        seekSize.setProgress((int)Math.max(40, Math.min(200, cfg.size)));
        seekAlpha.setProgress((int)(cfg.alpha*100));
        btnCancel.setOnClickListener(v->dismiss());
        btnOk.setOnClickListener(v->{
            if(!"panel".equals(cfg.type)){
                cfg.toggle=chkToggle.isChecked();
                cfg.passThroughWhileHeld=chkPass.isChecked();
                cfg.keyCode=codes[spKey.getSelectedItemPosition()];
            }
            cfg.size=Math.max(40, seekSize.getProgress());
            cfg.alpha=seekAlpha.getProgress()/100f;
            dismiss();
        });
    }
}

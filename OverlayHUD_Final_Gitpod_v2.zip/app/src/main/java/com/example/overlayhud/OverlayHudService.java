package com.example.overlayhud;
import android.app.*;
import android.content.*;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.view.*;
import android.widget.FrameLayout;
import androidx.core.app.NotificationCompat;
import java.util.*;
public class OverlayHudService extends Service {
    public static final String ACTION_TOGGLE="com.example.overlayhud.TOGGLE";
    public static final String ACTION_SWITCH_IME="com.example.overlayhud.SWITCH_IME";
    private WindowManager wm;
    private FrameLayout panelRoot;   // Layer 1 (bottom), not touchable in runtime
    private FrameLayout buttonsRoot; // Layer 2 (top), touchable
    private boolean visible=true;
    private Preset preset;
    @Override public void onCreate(){
        super.onCreate();
        wm=(WindowManager)getSystemService(WINDOW_SERVICE);
        preset=PresetManager.load(this);
        createWindows();
        inflateFromPreset();
        startForeground(1, buildNotification());
    }
    private void createWindows(){
        int type = Build.VERSION.SDK_INT>=26? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                                            : WindowManager.LayoutParams.TYPE_PHONE;
        // panel window (bottom, not touchable)
        panelRoot = new FrameLayout(this);
        WindowManager.LayoutParams lpPanel=new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                       | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                       | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        lpPanel.gravity=Gravity.TOP|Gravity.START;
        // buttons window (top, touchable)
        buttonsRoot = new FrameLayout(this);
        WindowManager.LayoutParams lpButtons=new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                       | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        lpButtons.gravity=Gravity.TOP|Gravity.START;
        wm.addView(panelRoot, lpPanel);
        wm.addView(buttonsRoot, lpButtons);
    }
    private void inflateFromPreset(){
        panelRoot.removeAllViews();
        buttonsRoot.removeAllViews();
        // First, add all panels to panelRoot (layer 1)
        for(Preset.ButtonCfg c: preset.items){
            if("panel".equals(c.type)){
                MousePanelView v=new MousePanelView(this);
                v.cfg=c; v.editing=false; v.applyCfg();
                v.setX(c.x); v.setY(c.y);
                panelRoot.addView(v);
            }
        }
        // Then, add all buttons to buttonsRoot (layer 2)
        for(Preset.ButtonCfg c: preset.items){
            if(!"panel".equals(c.type)){
                FloatingButtonView v=new FloatingButtonView(this);
                v.cfg=c; v.editing=false; v.applyCfg();
                v.setX(c.x); v.setY(c.y); v.setElevation(20f);
                buttonsRoot.addView(v);
            }
        }
    }
    private Notification buildNotification(){
        String chId="overlayhud";
        NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        if(Build.VERSION.SDK_INT>=26){
            NotificationChannel ch=new NotificationChannel(chId, getString(R.string.notification_channel), NotificationManager.IMPORTANCE_LOW);
            nm.createNotificationChannel(ch);
        }
        PendingIntent piToggle=PendingIntent.getService(this,0,new Intent(this,OverlayHudService.class).setAction(ACTION_TOGGLE), PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        PendingIntent piIME=PendingIntent.getService(this,1,new Intent(this,OverlayHudService.class).setAction(ACTION_SWITCH_IME), PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        NotificationCompat.Builder b=new NotificationCompat.Builder(this,chId)
            .setContentTitle(getString(R.string.notification_title))
            .setContentText(getString(R.string.notification_text))
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true)
            .addAction(0, getString(R.string.toggle_hud), piToggle)
            .addAction(0, getString(R.string.switch_ime), piIME);
        return b.build();
    }
    @Override public int onStartCommand(Intent i, int f, int id){
        if(i!=null){
            String a=i.getAction();
            if(ACTION_TOGGLE.equals(a)){
                visible=!visible;
                panelRoot.setVisibility(visible?View.VISIBLE:View.GONE);
                buttonsRoot.setVisibility(visible?View.VISIBLE:View.GONE);
            } else if(ACTION_SWITCH_IME.equals(a)){
                // open system IME picker overlay (cannot programmatically pick silently)
                ((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).showInputMethodPicker();
            }
        }
        return START_STICKY;
    }
    @Override public void onDestroy(){
        super.onDestroy();
        if(panelRoot!=null) wm.removeView(panelRoot);
        if(buttonsRoot!=null) wm.removeView(buttonsRoot);
    }
    @Override public IBinder onBind(Intent intent){ return null; }
}

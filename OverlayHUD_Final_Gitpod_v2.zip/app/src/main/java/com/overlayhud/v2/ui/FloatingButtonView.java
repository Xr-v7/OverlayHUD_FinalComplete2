
package com.overlayhud.v2.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;

import com.overlayhud.v2.ime.WASDInputMethodService;
import com.overlayhud.v2.model.Preset;

public class FloatingButtonView extends View {

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private Preset.ButtonItem data = new Preset.ButtonItem();
    private boolean active = false;
    private int trackedPointerId = -1;

    public FloatingButtonView(Context c){
        super(c);
        setClickable(true);
    }

    public void bind(Preset.ButtonItem it){
        data = it;
        setAlpha(data.opacity);
        invalidate();
    }

    @Override protected void onDraw(Canvas c){
        float r = Math.min(getWidth(), getHeight())/2f;
        p.setColor(0xFF000000);
        p.setAlpha((int)(255*getAlpha()));
        c.drawCircle(getWidth()/2f, getHeight()/2f, r*0.9f, p);
    }

    private WASDInputMethodService ime(){
        // Try to reach current IME via service instance is not trivial; in a real app use a binder or event bus.
        return null;
    }

    private void setKey(boolean down){
        // Placeholder: In production, route to IME through a shared singleton or broadcast.
        // This sample just toasts state.
        Toast.makeText(getContext(), (down?"DOWN ":"UP ")+data.key, Toast.LENGTH_SHORT).show();
    }

    @Override public boolean onTouchEvent(MotionEvent e){
        switch (e.getActionMasked()){
            case MotionEvent.ACTION_DOWN:{
                trackedPointerId = e.getPointerId(0);
                if (data.toggle){
                    active = !active;
                    setKey(active);
                }else{
                    active = true;
                    setKey(true);
                }
                return true;
            }
            case MotionEvent.ACTION_MOVE:{
                // if exclusive: do nothing; we keep consuming. If non-exclusive: still consume within bounds
                return true;
            }
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:{
                if (!data.toggle && active){
                    setKey(false);
                    active = false;
                }
                trackedPointerId = -1;
                return true;
            }
        }
        return super.onTouchEvent(e);
    }
}

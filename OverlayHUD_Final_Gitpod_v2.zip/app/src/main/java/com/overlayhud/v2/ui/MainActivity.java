
package com.overlayhud.v2.ui;

import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.overlayhud.v2.R;
import com.overlayhud.v2.core.OverlayHudService;

public class MainActivity extends AppCompatActivity {

    @Override protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button start = findViewById(R.id.btnStart);
        Button stop = findViewById(R.id.btnStop);
        Button config = findViewById(R.id.btnConfig);

        start.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName()));
                startActivity(i);
            } else {
                startService(new Intent(this, OverlayHudService.class));
            }
        });
        stop.setOnClickListener(v -> stopService(new Intent(this, OverlayHudService.class)));
        config.setOnClickListener(v -> startActivity(new Intent(this, ConfigActivity.class)));
    }
}

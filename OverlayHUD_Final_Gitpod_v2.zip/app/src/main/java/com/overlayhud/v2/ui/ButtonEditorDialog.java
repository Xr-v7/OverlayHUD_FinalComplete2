
package com.overlayhud.v2.ui;

import android.app.AlertDialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.Spinner;

import com.overlayhud.v2.R;
import com.overlayhud.v2.model.Preset;

public class ButtonEditorDialog {

    public interface OnSave { void onSave(Preset.ButtonItem updated); }

    public static void show(Context ctx, Preset.ButtonItem src, OnSave cb){
        View v = LayoutInflater.from(ctx).inflate(R.layout.dialog_button_editor, null, false);
        Spinner key = v.findViewById(R.id.spKey);
        CheckBox toggle = v.findViewById(R.id.cbToggle);
        CheckBox exclusive = v.findViewById(R.id.cbExclusive);
        SeekBar size = v.findViewById(R.id.skSize);
        SeekBar opacity = v.findViewById(R.id.skOpacity);

        String[] keys = new String[]{"W","A","S","D","UP","DOWN","LEFT","RIGHT","SPACE","ENTER"};
        key.setAdapter(new ArrayAdapter<>(ctx, android.R.layout.simple_list_item_1, keys));
        int sel = 0; for (int i=0;i<keys.length;i++){ if (keys[i].equalsIgnoreCase(src.key)) sel=i; }
        key.setSelection(sel);
        toggle.setChecked(src.toggle);
        exclusive.setChecked(src.exclusive);
        size.setProgress((int)src.size);
        opacity.setProgress((int)(src.opacity*100));

        new AlertDialog.Builder(ctx)
            .setTitle(R.string.editor_title)
            .setView(v)
            .setPositiveButton(R.string.editor_ok, (d, w)->{
                Preset.ButtonItem out = new Preset.ButtonItem();
                out.key = keys[key.getSelectedItemPosition()];
                out.toggle = toggle.isChecked();
                out.exclusive = exclusive.isChecked();
                out.size = Math.max(100, size.getProgress());
                out.opacity = Math.max(0.1f, opacity.getProgress()/100f);
                cb.onSave(out);
            })
            .setNegativeButton(R.string.editor_cancel, null)
            .show();
    }
}


package com.overlayhud.v2.ui;

import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.overlayhud.v2.R;
import com.overlayhud.v2.model.Preset;
import com.overlayhud.v2.model.PresetManager;

public class ConfigActivity extends AppCompatActivity {

    private FrameLayout canvas;
    private Preset preset;

    @Override protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_config);
        canvas = findViewById(R.id.canvas);
        preset = PresetManager.load(this);
        inflatePreset();

        Button addBtn = findViewById(R.id.btnAddButton);
        Button addPanel = findViewById(R.id.btnAddPanel);
        Button save = findViewById(R.id.btnSave);
        Button clear = findViewById(R.id.btnClear);
        Button exit = findViewById(R.id.btnExit);

        addBtn.setOnClickListener(v -> {
            Preset.ButtonItem it = new Preset.ButtonItem();
            it.x = 200; it.y = 200; it.layer = 2;
            preset.items.add(it);
            inflatePreset();
        });
        addPanel.setOnClickListener(v -> {
            Preset.MousePanelItem it = new Preset.MousePanelItem();
            it.x = 400; it.y = 400; it.size = 300; it.layer = 1;
            preset.items.add(it);
            inflatePreset();
        });
        save.setOnClickListener(v -> PresetManager.save(this, preset));
        clear.setOnClickListener(v -> { preset.items.clear(); inflatePreset(); });
        exit.setOnClickListener(v -> finish());
    }

    private void inflatePreset(){
        canvas.removeAllViews();
        // panel first
        for (Preset.Item it: preset.items){
            if (it instanceof Preset.MousePanelItem){
                MousePanelView v = new MousePanelView(this);
                v.setShowDebug(true);
                addAt(v, it);
            }
        }
        // buttons
        for (Preset.Item it: preset.items){
            if (it instanceof Preset.ButtonItem){
                FloatingButtonView v = new FloatingButtonView(this);
                addAt(v, it);
                v.setOnClickListener(view -> {
                    ButtonEditorDialog.show(this, (Preset.ButtonItem) it, updated -> {
                        ((Preset.ButtonItem) it).key = updated.key;
                        ((Preset.ButtonItem) it).toggle = updated.toggle;
                        ((Preset.ButtonItem) it).exclusive = updated.exclusive;
                        it.size = updated.size; it.opacity = updated.opacity;
                        v.bind((Preset.ButtonItem) it);
                    });
                });
                v.bind((Preset.ButtonItem) it);
                v.setAlpha(it.opacity);
            }
        }
    }

    private void addAt(View v, Preset.Item it){
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams((int)it.size, (int)it.size);
        lp.leftMargin = (int)it.x; lp.topMargin = (int)it.y;
        lp.gravity = Gravity.TOP|Gravity.START;
        canvas.addView(v, lp);
    }
}

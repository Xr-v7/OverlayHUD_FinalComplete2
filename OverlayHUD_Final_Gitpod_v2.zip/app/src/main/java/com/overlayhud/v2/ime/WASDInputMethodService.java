
package com.overlayhud.v2.ime;

import android.inputmethodservice.InputMethodService;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;

public class WASDInputMethodService extends InputMethodService {

    @Override public View onCreateInputView() {
        // No UI keyboard; purely programmatic
        View v = new View(this);
        v.setMinimumHeight(1);
        return v;
    }

    public void sendKey(String key, boolean down){
        InputConnection ic = getCurrentInputConnection();
        if (ic==null) return;
        int code = translate(key);
        long t = System.currentTimeMillis();
        KeyEvent ev = new KeyEvent(down?KeyEvent.ACTION_DOWN:KeyEvent.ACTION_UP, code);
        ic.sendKeyEvent(ev);
    }

    private int translate(String key){
        String k = key.toUpperCase();
        if (k.length()==1){
            char c = k.charAt(0);
            if (c>='A' && c<='Z') return KeyEvent.KEYCODE_A + (c-'A');
            if (c>='0' && c<='9') return KeyEvent.KEYCODE_0 + (c-'0');
        }
        switch (k){
            case "SPACE": return KeyEvent.KEYCODE_SPACE;
            case "ENTER": return KeyEvent.KEYCODE_ENTER;
            case "UP": return KeyEvent.KEYCODE_DPAD_UP;
            case "DOWN": return KeyEvent.KEYCODE_DPAD_DOWN;
            case "LEFT": return KeyEvent.KEYCODE_DPAD_LEFT;
            case "RIGHT": return KeyEvent.KEYCODE_DPAD_RIGHT;
            default: return KeyEvent.KEYCODE_UNKNOWN;
        }
    }
}

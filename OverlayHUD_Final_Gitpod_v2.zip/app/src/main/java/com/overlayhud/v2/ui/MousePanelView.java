
package com.overlayhud.v2.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.View;

import com.overlayhud.v2.model.Preset;

public class MousePanelView extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private Preset.MousePanelItem data = new Preset.MousePanelItem();
    private boolean showDebug = false;

    public MousePanelView(Context c){
        super(c);
        setClickable(false);
    }

    public void bind(Preset.MousePanelItem it){
        data = it;
        setAlpha(0f); // invisible at runtime
        invalidate();
    }

    public void setShowDebug(boolean b){
        showDebug = b; invalidate();
    }

    @Override protected void onDraw(Canvas c){
        if (!showDebug) return;
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(4f);
        p.setColor(0x55FFFFFF);
        c.drawRect(0,0,getWidth(),getHeight(),p);
    }
}


package com.overlayhud.v2.model;

import android.content.Context;
import android.content.SharedPreferences;

public class PresetManager {
    private static final String PREF = "presets_v2";
    private static final String KEY = "current";

    public static void save(Context ctx, Preset p){
        try {
            String s = p.toJson().toString();
            SharedPreferences sp = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE);
            sp.edit().putString(KEY, s).apply();
        }catch (Exception ignored){}
    }

    public static Preset load(Context ctx){
        SharedPreferences sp = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        String s = sp.getString(KEY, null);
        if (s==null) return new Preset();
        try { return Preset.fromJson(s); } catch (Exception e){ return new Preset(); }
    }
}


package com.overlayhud.v2.access;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.view.accessibility.AccessibilityEvent;

public class MouseAccessibilityService extends AccessibilityService {
    @Override public void onAccessibilityEvent(AccessibilityEvent event) { }
    @Override public void onInterrupt() { }

    public void tap(float x, float y){
        Path p = new Path(); p.moveTo(x,y);
        GestureDescription.StrokeDescription s =
            new GestureDescription.StrokeDescription(p, 0, 10);
        GestureDescription g = new GestureDescription.Builder().addStroke(s).build();
        dispatchGesture(g, null, null);
    }
}

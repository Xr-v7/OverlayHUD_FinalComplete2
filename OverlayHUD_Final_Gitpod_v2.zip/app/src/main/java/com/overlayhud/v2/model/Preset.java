
package com.overlayhud.v2.model;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class Preset {
    public List<Item> items = new ArrayList<>();

    public static abstract class Item {
        public float x, y; // px
        public float size = 160f; // dp-like px
        public float opacity = 0.66f;
        public int layer = 2; // 1 panel, 2 buttons by default
        public abstract String type();
        public JSONObject toJson() throws JSONException {
            JSONObject o = new JSONObject();
            o.put("x", x); o.put("y", y); o.put("size", size); o.put("opacity", opacity); o.put("layer", layer);
            o.put("type", type());
            return o;
        }
        public void fromJson(JSONObject o) throws JSONException {
            x = (float)o.optDouble("x", 0);
            y = (float)o.optDouble("y", 0);
            size = (float)o.optDouble("size", 160);
            opacity = (float)o.optDouble("opacity", 0.66);
            layer = o.optInt("layer", 2);
        }
    }

    public static class ButtonItem extends Item {
        public String key = "W";
        public boolean toggle = false;
        public boolean exclusive = false; // bloquear arrastre inferior
        @Override public String type(){ return "button"; }
        @Override public JSONObject toJson() throws JSONException {
            JSONObject o = super.toJson();
            o.put("key", key); o.put("toggle", toggle); o.put("exclusive", exclusive);
            return o;
        }
        @Override public void fromJson(JSONObject o) throws JSONException {
            super.fromJson(o);
            key = o.optString("key", "W");
            toggle = o.optBoolean("toggle", false);
            exclusive = o.optBoolean("exclusive", false);
        }
    }

    public static class MousePanelItem extends Item {
        @Override public String type(){ return "panel"; }
        public MousePanelItem(){ layer = 1; opacity = 0.0f; }
    }

    public JSONObject toJson() throws JSONException {
        JSONObject root = new JSONObject();
        JSONArray arr = new JSONArray();
        for (Item i: items) arr.put(i.toJson());
        root.put("items", arr);
        return root;
    }

    public static Preset fromJson(String s) throws JSONException {
        Preset p = new Preset();
        JSONObject root = new JSONObject(s);
        JSONArray arr = root.optJSONArray("items");
        if (arr!=null){
            for(int i=0;i<arr.length();i++){
                JSONObject o = arr.getJSONObject(i);
                String t = o.optString("type","button");
                Item it;
                if ("panel".equals(t)) it = new MousePanelItem();
                else it = new ButtonItem();
                it.fromJson(o);
                p.items.add(it);
            }
        }
        return p;
    }
}

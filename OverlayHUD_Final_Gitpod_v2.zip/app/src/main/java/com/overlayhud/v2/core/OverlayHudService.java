
package com.overlayhud.v2.core;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.WindowManager;

import androidx.core.app.NotificationCompat;

import com.overlayhud.v2.OverlayApp;
import com.overlayhud.v2.R;
import com.overlayhud.v2.ime.WASDInputMethodService;
import com.overlayhud.v2.model.Preset;
import com.overlayhud.v2.model.PresetManager;
import com.overlayhud.v2.ui.ConfigActivity;
import com.overlayhud.v2.ui.FloatingButtonView;
import com.overlayhud.v2.ui.MousePanelView;

import java.util.ArrayList;
import java.util.List;

public class OverlayHudService extends Service {

    public static final String ACTION_TOGGLE = "toggle";
    public static final String ACTION_IME = "ime";

    private WindowManager wm;
    private boolean visible = true;
    private final List<Object> windows = new ArrayList<>();

    @Override public void onCreate() {
        super.onCreate();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        startForeground(1, buildNotification());
        showFromPreset();
    }

    private Notification buildNotification(){
        Intent toggle = new Intent(this, OverlayHudService.class).setAction(ACTION_TOGGLE);
        PendingIntent piToggle = PendingIntent.getService(this, 1, toggle, PendingIntent.FLAG_IMMUTABLE);

        Intent ime = new Intent(android.provider.Settings.ACTION_INPUT_METHOD_SETTINGS);
        PendingIntent piIme = PendingIntent.getActivity(this, 2, ime, PendingIntent.FLAG_IMMUTABLE);

        Intent cfg = new Intent(this, ConfigActivity.class);
        PendingIntent piCfg = PendingIntent.getActivity(this, 3, cfg, PendingIntent.FLAG_IMMUTABLE);

        return new NotificationCompat.Builder(this, OverlayApp.CH_ID)
                .setContentTitle(getString(R.string.app_name))
                .setContentText(getString(R.string.notif_running))
                .setSmallIcon(R.mipmap.ic_launcher)
                .setOngoing(true)
                .addAction(0, getString(R.string.action_toggle), piToggle)
                .addAction(0, getString(R.string.action_ime), piIme)
                .setContentIntent(piCfg)
                .build();
    }

    private WindowManager.LayoutParams baseLp(){
        int type = Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
        );
        lp.gravity = Gravity.TOP|Gravity.START;
        return lp;
    }

    private void showFromPreset(){
        Preset p = PresetManager.load(this);
        // First: panels (layer 1)
        for (Preset.Item it: p.items){
            if (it instanceof Preset.MousePanelItem){
                MousePanelView v = new MousePanelView(this);
                v.bind((Preset.MousePanelItem) it);
                WindowManager.LayoutParams lp = baseLp();
                lp.x = (int)it.x; lp.y = (int)it.y;
                lp.width = lp.height = (int)it.size;
                // Panel: pass-through by default -> NOT_TOUCHABLE
                lp.flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
                wm.addView(v, lp);
                windows.add(v);
            }
        }
        // Second: buttons (layer 2)
        for (Preset.Item it: p.items){
            if (it instanceof Preset.ButtonItem){
                FloatingButtonView v = new FloatingButtonView(this);
                v.bind((Preset.ButtonItem) it);
                WindowManager.LayoutParams lp = baseLp();
                lp.x = (int)it.x; lp.y = (int)it.y;
                lp.width = lp.height = (int)it.size;
                // If exclusive, still standard touchable window (blocks underlying within its bounds)
                wm.addView(v, lp);
                windows.add(v);
            }
        }
    }

    private void clearAll(){
        for (Object o: windows){
            try {
                if (o instanceof android.view.View){
                    wm.removeView((android.view.View)o);
                }
            }catch (Exception ignored){}
        }
        windows.clear();
    }

    private void toggle(){
        visible = !visible;
        for (Object o: windows){
            if (o instanceof android.view.View){
                android.view.View v = (android.view.View)o;
                v.setVisibility(visible? android.view.View.VISIBLE: android.view.View.GONE);
            }
        }
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent!=null){
            if (ACTION_TOGGLE.equals(intent.getAction())) toggle();
            else if (ACTION_IME.equals(intent.getAction())){
                Intent i = new Intent(android.provider.Settings.ACTION_INPUT_METHOD_SETTINGS);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
            }
        }
        return START_STICKY;
    }

    @Override public void onDestroy() {
        clearAll();
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}

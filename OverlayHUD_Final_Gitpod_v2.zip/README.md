# OverlayHUD Final (Gitpod v2)
- Panel de mouse en **capa 1** (abajo, NOT_TOUCHABLE en runtime).
- Botones en **capa 2** (arriba, touchable).
- Opción por botón: **Permitir arrastre al juego mientras mantengo** (si está activo, el servicio de Accesibilidad envía micro-gestos mientras el botón está presionado).
- Editor flotante único por botón.
- Presets persistentes (JSON en SharedPreferences).
- IME propio para mandar KeyEvents.

## Gitpod
- Abre en Gitpod y se instalará el SDK.
- Compila con: `gradle assembleDebug`

## Notas
- Cambiar IME se hace con el **picker del sistema** invocado desde la notificación.

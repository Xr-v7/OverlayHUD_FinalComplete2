#!/usr/bin/env bash
set -e
sudo apt-get update -y
sudo apt-get install -y openjdk-17-jdk unzip wget
export JAVA_HOME=/usr/lib/jvm/java-17-openjdk-amd64
export PATH=$JAVA_HOME/bin:$PATH
ANDROID_SDK_ROOT=$HOME/android-sdk
mkdir -p "$ANDROID_SDK_ROOT"
cd "$ANDROID_SDK_ROOT"
if [ ! -d "cmdline-tools/latest" ]; then
  wget -q https://dl.google.com/android/repository/commandlinetools-linux-9477386_latest.zip -O cmdtools.zip
  unzip -q cmdtools.zip
  rm cmdtools.zip
  mkdir -p cmdline-tools/latest
  mv cmdline-tools/* cmdline-tools/latest/ || true
fi
export PATH="$ANDROID_SDK_ROOT/cmdline-tools/latest/bin:$ANDROID_SDK_ROOT/platform-tools:$PATH"
yes | sdkmanager --licenses >/dev/null
sdkmanager "platform-tools" "platforms;android-34" "build-tools;34.0.0" >/dev/null
export ANDROID_HOME=$ANDROID_SDK_ROOT
echo "sdk.dir=$ANDROID_SDK_ROOT" > local.properties

#!/usr/bin/env bash
set -euo pipefail
echo "Installing OpenJDK 17 and Gradle via sdkman, and Android SDK commandline tools..."

sudo apt-get update -y
sudo apt-get install -y openjdk-17-jdk unzip curl

# Install sdkman to get gradle
curl -s "https://get.sdkman.io" | bash
source "$HOME/.sdkman/bin/sdkman-init.sh"
sdk install gradle 8.4.2

# Install Android command-line tools
ANDROID_SDK_ROOT="$HOME/Android/Sdk"
mkdir -p "$ANDROID_SDK_ROOT/cmdline-tools"
cd /tmp
if [ ! -f commandlinetools-linux_latest.zip ]; then
    curl -O https://dl.google.com/android/repository/commandlinetools-linux-9477386_latest.zip
fi
unzip -q commandlinetools-linux_latest.zip -d "$ANDROID_SDK_ROOT/cmdline-tools"
mv "$ANDROID_SDK_ROOT/cmdline-tools/cmdline-tools" "$ANDROID_SDK_ROOT/cmdline-tools/latest" || true

export PATH="$ANDROID_SDK_ROOT/cmdline-tools/latest/bin:$PATH"
yes | sdkmanager --sdk_root="$ANDROID_SDK_ROOT" --licenses
sdkmanager --sdk_root="$ANDROID_SDK_ROOT" "platform-tools" "platforms;android-34" "build-tools;34.0.0"

echo "Android SDK and Gradle installed. Running ./gradlew assembleDebug next..."

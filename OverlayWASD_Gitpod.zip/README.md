# OverlayWASD_Gitpod

This Android project provides a minimal IME that shows on-screen buttons (W A S D SPACE)
and sends KeyEvents to the current input connection.

## How to build in Gitpod

1. Push this repo to GitHub.
2. Open Gitpod: https://gitpod.io/#https://github.com/YOURUSER/REPO
3. Gitpod will run .gitpod/setup-android.sh to install Java, Gradle, and Android SDK tools.
4. The task runs `./gradlew assembleDebug`.

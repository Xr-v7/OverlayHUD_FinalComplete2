package com.example.overlayhud;
import android.content.Intent; import android.net.Uri; import android.os.Bundle; import android.provider.Settings; import android.widget.Button; import androidx.appcompat.app.AppCompatActivity;
public class MainActivity extends AppCompatActivity {
  @Override protected void onCreate(Bundle s) { super.onCreate(s); setContentView(R.layout.activity_main); Button b = findViewById(R.id.btnOverlayPermission); b.setOnClickListener(v->{ if (!Settings.canDrawOverlays(this)) startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName()))); }); findViewById(R.id.btnEnableAccessibility).setOnClickListener(v->{ startActivity(new Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS)); }); }
}

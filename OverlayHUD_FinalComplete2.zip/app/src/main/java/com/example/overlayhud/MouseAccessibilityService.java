package com.example.overlayhud; import android.accessibilityservice.AccessibilityService; import android.accessibilityservice.GestureDescription; import android.graphics.Path; import android.view.accessibility.AccessibilityEvent; import android.content.Intent; import android.content.BroadcastReceiver; import android.content.IntentFilter; import android.content.Context;
public class MouseAccessibilityService extends AccessibilityService {
  public static final String ACTION_MOUSE = "com.example.overlayhud.MOUSE";
  public static final String EXTRA_CMD = "cmd"; public static final String EXTRA_X="x"; public static final String EXTRA_Y="y";
  private BroadcastReceiver receiver = new BroadcastReceiver(){ public void onReceive(Context c, Intent i){ if (i==null) return; String cmd = i.getStringExtra(EXTRA_CMD); if ("TAP".equals(cmd) && android.os.Build.VERSION.SDK_INT>=24){ int x=i.getIntExtra(EXTRA_X,100); int y=i.getIntExtra(EXTRA_Y,100); Path p = new Path(); p.moveTo(x,y); GestureDescription.StrokeDescription sd = new GestureDescription.StrokeDescription(p,0,50); dispatchGesture(new GestureDescription.Builder().addStroke(sd).build(), null, null); } } };
  @Override public void onServiceConnected(){ registerReceiver(receiver, new IntentFilter(ACTION_MOUSE)); }
  @Override public void onAccessibilityEvent(AccessibilityEvent event){} @Override public void onInterrupt(){} @Override public void onDestroy(){ try{ unregisterReceiver(receiver);}catch(Exception e){} super.onDestroy(); }
}
